import java.io.*;

public class CRCGenerator {
    public static void main(String args[]) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int[] data, divisor, rem, crc;
        int dataBits, divisorBits, totLength;

        System.out.println("Enter number of data bits: ");
        dataBits = Integer.parseInt(br.readLine());
        data = new int[dataBits];
        
        System.out.println("Enter data bits: ");
        for (int i = 0; i < dataBits; i++)
            data[i] = Integer.parseInt(br.readLine());

        System.out.println("Enter number of bits in divisor: ");
        divisorBits = Integer.parseInt(br.readLine());
        divisor = new int[divisorBits];

        System.out.println("Enter divisor bits: ");
        for (int i = 0; i < divisorBits; i++)
            divisor[i] = Integer.parseInt(br.readLine());

        totLength = dataBits + divisorBits - 1;
        rem = new int[totLength];
        crc = new int[totLength];

        /*---CRC GENERATION---*/
        System.arraycopy(data, 0, rem, 0, data.length);

        rem = divide(rem, divisor);

        for (int i = 0; i < data.length; i++) {
            crc[i] = (data[i] ^ rem[i]);
        }

        System.out.println("CRC code: ");
        for (int value : crc) {
            System.out.print(value);
        }

        /*---ERROR DETECTION---*/
        System.out.println("\nEnter CRC code of " + totLength + " bits: ");
        for (int i = 0; i < crc.length; i++) {
            crc[i] = Integer.parseInt(br.readLine());
        }

        rem = divide(crc, divisor);

        for (int value : rem) {
            if (value != 0) {
                System.out.println("Error");
                break;
            }
            if (value == rem[rem.length - 1]) {
                System.out.println("No Error");
            }
        }

        System.out.println("THANK YOU.... :)");
    }

    static int[] divide(int rem[], int divisor[]) {
        int cur = 0;
        while (true) {
            for (int i = 0; i < divisor.length; i++) {
                rem[cur + i] = (rem[cur + i] ^ divisor[i]);
            }

            while (rem[cur] == 0 && cur != rem.length - 1) {
                cur++;
            }

            if ((rem.length - cur) < divisor.length) {
                break;
            }
        }
        return rem;
    }
}
