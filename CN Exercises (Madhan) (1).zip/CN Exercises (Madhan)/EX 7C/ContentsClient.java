import java.net.*;
import java.io.*;

public class ContentsClient {
    public static void main(String args[]) throws Exception {
        Socket sock = new Socket("127.0.0.1", 4000);
        System.out.print("Enter the file name: ");
        
        BufferedReader keyRead = new BufferedReader(new InputStreamReader(System.in));
        String fname = keyRead.readLine();
        
        PrintWriter ostream = new PrintWriter(sock.getOutputStream(), true);
        ostream.println(fname);
        
        InputStream istream = sock.getInputStream();
        BufferedReader socketRead = new BufferedReader(new InputStreamReader(istream));
        String str;
        
        while ((str = socketRead.readLine()) != null) {
            System.out.println(str);
        }
        
        ostream.close();
        socketRead.close();
        keyRead.close();
        sock.close();
    }
}
