import java.io.*;
import java.net.*;

public class talkclient {
    public static void main(String args[]) throws Exception {
        Socket c = null;
        BufferedReader usr_inp = null;
        BufferedReader din = new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream dout = null;

        try {
            c = new Socket("127.0.0.1", 1234);
            usr_inp = new BufferedReader(new InputStreamReader(c.getInputStream()));
            dout = new DataOutputStream(c.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (c != null && usr_inp != null && dout != null) {
            String unip;
            System.out.println("\nEnter the message for the server:");

            while ((unip = din.readLine()) != null) {
                dout.writeBytes(unip + "\n");
                System.out.println("Waiting for reply...");
                String reply = usr_inp.readLine();
                System.out.println("Server's reply: " + reply);
                System.out.print("\nEnter your message: ");
            }
        }

        din.close();
        if (usr_inp != null) usr_inp.close();
        if (dout != null) dout.close();
        if (c != null) c.close();
    }
}


//javac -Xlint:deprecation talkclient.java
