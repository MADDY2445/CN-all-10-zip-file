import java.io.*;
import java.net.*;

public class talkserver {
    public static void main(String args[]) throws Exception {
        ServerSocket m = null;
        Socket c = null;
        BufferedReader usr_inp = null;
        BufferedReader din = new BufferedReader(new InputStreamReader(System.in));
        DataOutputStream dout = null;

        try {
            m = new ServerSocket(1234);
            System.out.println("Server listening on port 1234...");
            c = m.accept();
            usr_inp = new BufferedReader(new InputStreamReader(c.getInputStream()));
            dout = new DataOutputStream(c.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (c != null && usr_inp != null) {
            String unip;
            while (true) {
                System.out.println("\nMessage from client:");
                String m1 = usr_inp.readLine();
                System.out.println(m1);
                System.out.print("Enter message: ");
                unip = din.readLine();
                dout.writeBytes(unip + "\n");
                dout.flush(); // Make sure the data is sent immediately
            }
        }

        if (dout != null) dout.close();
        if (usr_inp != null) usr_inp.close();
        if (c != null) c.close();
        if (m != null) m.close();
    }
}

//javac -Xlint:deprecation talkserver.java

