import java.net.*;
import java.io.*;

public class SlideReceiver {
    public static void main(String[] args) {
        try {
            Socket s = new Socket(InetAddress.getLocalHost(), 10);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            int rptr = -1;
            int rws = 8;
            String[] rbuf = new String[8];
            String ch;

            System.out.println();

            do {
                int nf = Integer.parseInt(in.readLine());

                if (nf <= rws - 1) {
                    for (int i = 0; i < nf; i++) {
                        rptr = (rptr + 1) % 8;
                        rbuf[rptr] = in.readLine();
                        System.out.println("The received Frame " + rptr + " is: " + rbuf[rptr]);
                    }

                    rws -= nf;
                    System.out.println("\nAcknowledgment sent\n");
                    out.println((rptr + 1) % 8);
                    rws += nf;
                } else {
                    break;
                }

                ch = in.readLine();
            } while ("yes".equals(ch));

            // Close resources
            in.close();
            out.close();
            s.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}




//javac -Xlint:deprecation SLideReceiver.java